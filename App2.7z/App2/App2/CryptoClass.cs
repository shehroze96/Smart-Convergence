﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Security.Cryptography;
using Windows.Security.Cryptography.Core;
using Windows.Storage.Streams;

namespace App2
{
    class CryptoClass
    {
        #region Buffer and IV
        static IBuffer IV;

        static void GenerateIV()
        {

            IV = CryptographicBuffer.GenerateRandom(16);

        }
        #endregion

        #region AES encryption
        public static string AES_Encrypt(string input, string pass)
        {
            GenerateIV();
            SymmetricKeyAlgorithmProvider SAP = SymmetricKeyAlgorithmProvider.OpenAlgorithm(SymmetricAlgorithmNames.AesCbcPkcs7);
            CryptographicKey AES;
            HashAlgorithmProvider HAP = HashAlgorithmProvider.OpenAlgorithm(HashAlgorithmNames.Md5);
            CryptographicHash Hash_AES = HAP.CreateHash();

            string encrypted = "";
            try

            {
                byte[] hash = new byte[32];
                Hash_AES.Append(CryptographicBuffer.CreateFromByteArray(System.Text.Encoding.UTF8.GetBytes(pass)));
                byte[] temp;
                CryptographicBuffer.CopyToByteArray(Hash_AES.GetValueAndReset(), out temp);

                Array.Copy(temp, 0, hash, 0, 16);
                Array.Copy(temp, 0, hash, 16, 16);

                AES = SAP.CreateSymmetricKey(CryptographicBuffer.CreateFromByteArray(hash));

                IBuffer Buffer = CryptographicBuffer.CreateFromByteArray(System.Text.Encoding.UTF8.GetBytes(input));
                //IBuffer IV = CryptographicBuffer.GenerateRandom(16);
                encrypted = CryptographicBuffer.EncodeToBase64String(CryptographicEngine.Encrypt(AES, Buffer, IV));

                return encrypted;
            }

            catch (Exception ex)
            {
                return null;
            }


        }
        #endregion

        #region AES Decrypt
        public static string AES_Decrypt(string input, string pass)
        {

            SymmetricKeyAlgorithmProvider SAP = SymmetricKeyAlgorithmProvider.OpenAlgorithm(SymmetricAlgorithmNames.AesCbcPkcs7);
            CryptographicKey AES;
            HashAlgorithmProvider HAP = HashAlgorithmProvider.OpenAlgorithm(HashAlgorithmNames.Md5);
            CryptographicHash Hash_AES = HAP.CreateHash();

            string decrypted = "";
            try
            {
                byte[] hash = new byte[32];
                Hash_AES.Append(CryptographicBuffer.CreateFromByteArray(System.Text.Encoding.UTF8.GetBytes(pass)));
                byte[] temp;
                CryptographicBuffer.CopyToByteArray(Hash_AES.GetValueAndReset(), out temp);

                Array.Copy(temp, 0, hash, 0, 16);
                Array.Copy(temp, 0, hash, 16, 16);

                AES = SAP.CreateSymmetricKey(CryptographicBuffer.CreateFromByteArray(hash));

                IBuffer Buffer = CryptographicBuffer.DecodeFromBase64String(input);
                byte[] Decrypted;
                CryptographicBuffer.CopyToByteArray(CryptographicEngine.Decrypt(AES, Buffer, IV), out Decrypted);
                decrypted = System.Text.Encoding.UTF8.GetString(Decrypted, 0, Decrypted.Length);

                return decrypted;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        #endregion

        private static CryptographicKey keyPair;

        public static string generateSessionKey()
        {
            keyPair = (AsymmetricKeyAlgorithmProvider.OpenAlgorithm(AsymmetricAlgorithmNames.RsaPkcs1)).CreateKeyPair(2048);
            return getPreGeneratedPublicKey();
        }

        public static string getPreGeneratedPublicKey()
        {
            return CryptographicBuffer.EncodeToBase64String(keyPair.ExportPublicKey());
        }

        public static string RSA_Encrypt(string input, string publicKey)
        {
            AsymmetricKeyAlgorithmProvider RSAProvider = AsymmetricKeyAlgorithmProvider.OpenAlgorithm(AsymmetricAlgorithmNames.RsaPkcs1);
            CryptographicKey PK = RSAProvider.ImportPublicKey(CryptographicBuffer.DecodeFromBase64String(publicKey));
            IBuffer encData = CryptographicEngine.Encrypt(PK, CryptographicBuffer.CreateFromByteArray(Encoding.UTF8.GetBytes(input)), null);

            return CryptographicBuffer.EncodeToBase64String(encData);
        }

        public static string RSA_Decrypt(string input)
        {
            byte[] Decrypted;

            AsymmetricKeyAlgorithmProvider RSAProvider = AsymmetricKeyAlgorithmProvider.OpenAlgorithm(AsymmetricAlgorithmNames.RsaPkcs1);
            CryptographicBuffer.CopyToByteArray(CryptographicEngine.Decrypt(keyPair, CryptographicBuffer.DecodeFromBase64String(input), null), out Decrypted);

            return Encoding.UTF8.GetString(Decrypted, 0, Decrypted.Length);
        }
    }
}
