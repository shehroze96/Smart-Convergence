﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking;
using Windows.Networking.Sockets;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            initSocket();
        }

        #region encryption/decryption rsa/aes
        private void HamburgerButton_Click(object sender, RoutedEventArgs e)
        {
            MySplitView.IsPaneOpen = !MySplitView.IsPaneOpen;
        }

        private void aesEncrypt_Click(object sender, RoutedEventArgs e)
        {
            aesEncryptText.Text = CryptoClass.AES_Encrypt(aesEncryptText.Text, passwordText.Text);
        }

        private void aesDecrypt_Click(object sender, RoutedEventArgs e)
        {
            aesDecryptText.Text = CryptoClass.AES_Decrypt(aesEncryptText.Text, passwordText.Text);
        }

        private void publickey_Click(object sender, RoutedEventArgs e)
        {
            publicKeyText.Text = CryptoClass.generateSessionKey();
        }

        private void rsaEncrypt_Click(object sender, RoutedEventArgs e)
        {
            rsaEncryptText.Text = CryptoClass.RSA_Encrypt(rsaEncryptText.Text, publicKeyText.Text);
        }

        private void rsaDecrypt_Click(object sender, RoutedEventArgs e)
        {
            rsaDecryptText.Text = CryptoClass.RSA_Decrypt(rsaEncryptText.Text);
        }

        private void TCP_Click(object sender, RoutedEventArgs e)
        {
            MySplitView.IsPaneOpen = !MySplitView.IsPaneOpen;
        }


        #region TCP CODE
        StreamSocketListener receiveSocket = new StreamSocketListener();
        StreamSocket sendSocket = new StreamSocket();
        string port = "1337";


        public async void initSocket()
        {
            try
            {
                receiveSocket.ConnectionReceived += SocketListener_ConnectionReceived;
                await receiveSocket.BindServiceNameAsync(port);
            }
            catch (Exception ex)
            {
                ContentDialog dlg = new ContentDialog()
                {
                    Title = "TCP Error",
                    Content = "There was an error creating the socket, the App will nopw close",
                    PrimaryButtonText = "OK",
                    IsPrimaryButtonEnabled = true
                };
                await dlg.ShowAsync();
                Application.Current.Exit();
            }
        }
        public async void sendData(string recipientIP, string message)
        {
            try
            {
                sendSocket = new StreamSocket();
                HostName receipt = new HostName(recipientIP);
                await sendSocket.ConnectAsync(receipt, port);
                Stream streamOut = sendSocket.OutputStream.AsStreamForWrite();
                StreamWriter writer = new StreamWriter(streamOut);
                await writer.WriteLineAsync(message);
                await writer.FlushAsync();
            }
            catch (Exception)
            {

            }
        }

        private async void SocketListener_ConnectionReceived(StreamSocketListener sender, StreamSocketListenerConnectionReceivedEventArgs args)
        {
            Stream inStream = args.Socket.InputStream.AsStreamForRead();
            StreamReader reader = new StreamReader(inStream);
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, (async () => { receivedBox.Text += await reader.ReadLineAsync() + Environment.NewLine; }));

            //send response to sender of received message 
            /*
            Stream outStream = args.Socket.OutputStream.AsStreamForWrite();
            StreamWriter writer = new StreamWriter(outStream);
            await writer.WriteLineAync("Received");
            await writer.FlushAsync();
            */
        }

        private void sendButton_Click(object sender, RoutedEventArgs e)
        {
            sendData(IPBlock1.Text, messageBox.Text);
        }

    }

    
    #endregion






}
#endregion